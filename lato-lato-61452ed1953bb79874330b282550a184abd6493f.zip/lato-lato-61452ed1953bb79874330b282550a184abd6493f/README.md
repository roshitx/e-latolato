# Lato Lato tapi TapTap

Lato-lato simple dengan html css jquery


[![Lato Lato](https://media1.tenor.com/images/689c8e6dac443b3658dc6c5a6b293f95/tenor.gif?itemid=27359622 "Lato Lato")](https://media1.tenor.com/images/689c8e6dac443b3658dc6c5a6b293f95/tenor.gif?itemid=27359622 "Lato Lato")
